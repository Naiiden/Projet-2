#ifndef STATIQUE_H
#define STATIQUE_H
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/ioctl.h>
#include <time.h>

void centrerImageVertical(int largeur, int hauteur);
void centrerImage(int largeur, int hauteur);
int choisirImage();

#endif // STATIQUE_H
